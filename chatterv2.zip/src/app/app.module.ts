import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChatterHomeViewComponent } from './views/chatter-home-view/chatter-home-view.component';
import { ChatterLoginViewComponent } from './views/chatter-login-view/chatter-login-view.component';
import { AppRoutingModule } from './/app-routing.module';

import { HttpClientModule } from '@angular/common/http';
import { ChatterProfileViewComponent } from './views/chatter-profile-view/chatter-profile-view.component';
import { ChatterGroupsViewComponent } from './views/chatter-groups-view/chatter-groups-view.component';
import { ChatterUsersViewComponent } from './views/chatter-users-view/chatter-users-view.component';
import { ChatterDirectMessagesViewComponent } from './views/chatter-direct-messages-view/chatter-direct-messages-view.component';

@NgModule({
    declarations: [
        AppComponent,
        ChatterHomeViewComponent,
        ChatterLoginViewComponent,
        ChatterProfileViewComponent,
        ChatterGroupsViewComponent,
        ChatterUsersViewComponent,
        ChatterDirectMessagesViewComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        HttpClientModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
