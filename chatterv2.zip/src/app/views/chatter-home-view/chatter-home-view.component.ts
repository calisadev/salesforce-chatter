import { Component, OnInit } from '@angular/core';
import { GroupService } from '../../salesforce/services/group.service'
import { Group } from '../../salesforce/models/Group';
@Component({
    selector: 'app-chatter-home-view',
    templateUrl: './chatter-home-view.component.html',
    styleUrls: ['./chatter-home-view.component.css']
})
export class ChatterHomeViewComponent implements OnInit {

    constructor (private groupService: GroupService) {}

    public ngOnInit (): void {
        this.groupService.getAll();
    }

}
