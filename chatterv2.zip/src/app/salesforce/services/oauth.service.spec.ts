import { TestBed, inject } from '@angular/core/testing';

import { OAuthService } from './oauth.service';

describe('TokenService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [OAuthService]
        });
    });

    it('should be created', inject([OAuthService], (service: OAuthService) => {
        expect(service).toBeTruthy();
    }));
});
