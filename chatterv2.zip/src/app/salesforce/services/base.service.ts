import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../../services/authentication/authentication.service'
@Injectable({
    providedIn: 'root'
})
export class BaseService {

    constructor (private authenticationService: AuthenticationService, private http: HttpClient) {}
    
    public callGet<T> (resourcePath: string) {
        const headers = this.buildHeaders();
        const url = this.buildUrl(resourcePath);
        this.http.get<T>(url, headers).subscribe((result: any) => {
            console.log("OK here" + result.status);
            console.log(result);
        }, (error: Response) => {
            console.log("Error here");
            console.log(error);
        });
    }
    private buildHeaders (): any {
        const accessToken = this.authenticationService.getTokenInfo().access_token;
        const headers = {
            headers: new HttpHeaders().set('Content-Type', 'application/json')
                                      .set('Authorization', 'Bearer a')
        };
        return headers;
    }
    private buildUrl (resourcePath: string): string {
        const baseUrl = this.authenticationService.getTokenInfo().instance_url;
        return baseUrl + '/' + resourcePath;
    }
}
