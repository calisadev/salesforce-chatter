import { Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../../services/authentication/authentication.service';
import { Group } from '../models/Group'
@Injectable({
    providedIn: 'root'
})
export class GroupService {

    constructor (private baseService: BaseService) {}

    public getAll (): void {
        this.baseService.callGet<Group>('services/data/v43.0/chatter/groups');
    }
}
