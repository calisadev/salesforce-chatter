export interface AccessTokenInfo {
    access_token: string;
    signature: string;
    scope: string;
    id_token: string;
    instance_url: string;
    id: string;
    token_type: string;
    issued_at: string;
}